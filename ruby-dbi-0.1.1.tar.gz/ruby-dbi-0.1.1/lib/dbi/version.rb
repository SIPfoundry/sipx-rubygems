#
# $Id: version.rb,v 1.1.1.1 2006/01/04 02:03:22 francis Exp $
#

module DBI

VERSION = "0.0.23"

end
